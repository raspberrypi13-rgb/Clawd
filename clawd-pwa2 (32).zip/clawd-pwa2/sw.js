const CACHE = 'clawd-v5';
const ASSETS = ['./', './index.html', './style.css', './app.js',
                './manifest.json', './icons/icon-192.png', './icons/icon-512.png'];

/* ── 설치 & 캐시 ── */
self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE).then(c => c.addAll(ASSETS)).then(() => self.skipWaiting())
  );
});
self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
      .then(() => _checkAndNotify()) // 활성화 시 즉시 체크
  );
});

/* ── fetch: 캐시 우선 + 시간 체크 ── */
self.addEventListener('fetch', e => {
  // fetch 이벤트마다 (SW가 깨어날 때) 시간 체크
  _checkAndNotify();
  e.respondWith(
    caches.match(e.request).then(hit => {
      if (hit) return hit;
      return fetch(e.request).then(res => {
        if (!res || res.status !== 200 || res.type === 'opaque') return res;
        const clone = res.clone();
        caches.open(CACHE).then(c => c.put(e.request, clone));
        return res;
      });
    }).catch(() => caches.match('./index.html'))
  );
});

/* ════════════════════════════════
   알림 로직
════════════════════════════════ */
const MEAL_WINDOWS = [
  { start:7,  end:9,  title:'🍳 아침 밥 시간!',  body:'Clawd가 배고파하고 있어요 🦞', tag:'meal-morning' },
  { start:12, end:14, title:'🍱 점심 밥 시간!',  body:'냠냠 먹으러 와요! 🦀',          tag:'meal-lunch'   },
  { start:18, end:20, title:'🍚 저녁 밥 시간!',  body:'Clawd가 기다리고 있어요 💕',    tag:'meal-dinner'  },
];
const SLEEP_HOUR = 22;

// 발송 기록 (중복 방지): "tag-YYYY-MM-DD-HH-MM5" 형식
const _sent = new Set();

function _key(tag, date, h, m5) {
  return `${tag}-${date.getFullYear()}${date.getMonth()}${date.getDate()}-${h}-${m5}`;
}

function _notify(title, body, tag) {
  self.registration.showNotification(title, {
    body,
    tag,
    icon:  './icons/icon-192.png',
    badge: './icons/icon-192.png',
    vibrate: [200, 100, 200, 100, 200],
    requireInteraction: false,
    renotify: true,
    data: { url: './' }
  });
}

function _checkAndNotify() {
  const now  = new Date();
  const h    = now.getHours();
  const m    = now.getMinutes();
  const m5   = Math.floor(m / 5); // 5분 단위 버킷

  /* 밥시간: 범위 내 5분마다 */
  for (const meal of MEAL_WINDOWS) {
    if (h >= meal.start && h < meal.end) {
      const k = _key(meal.tag, now, h, m5);
      if (!_sent.has(k)) {
        _sent.add(k);
        _notify(meal.title, meal.body, meal.tag);
      }
    }
  }

  /* 잠자리: 22:00 */
  if (h === SLEEP_HOUR && m < 5) {
    const k = _key('sleep', now, h, 0);
    if (!_sent.has(k)) {
      _sent.add(k);
      _notify('💤 잠잘 시간!', 'Clawd랑 같이 자러 가요 🌙', 'sleep');
    }
  }

  // 날짜 바뀌면 _sent 초기화 (메모리 관리)
  if (_sent.size > 200) _sent.clear();
}

/* ── 앱에서 메시지: 명시적 시작 요청 ── */
self.addEventListener('message', e => {
  if (e.data?.type === 'START_NOTIFICATIONS') {
    _checkAndNotify();

    // 폴링 시작 (SW가 살아있는 한)
    if (!self._pollStarted) {
      self._pollStarted = true;
      setInterval(_checkAndNotify, 60 * 1000);
    }
  }
});

/* ── Periodic Background Sync (Chrome Android 지원 시) ── */
self.addEventListener('periodicsync', e => {
  if (e.tag === 'clawd-notify') {
    e.waitUntil(Promise.resolve(_checkAndNotify()));
  }
});

/* ── 알림 클릭 → 앱 열기 ── */
self.addEventListener('notificationclick', e => {
  e.notification.close();
  e.waitUntil(
    clients.matchAll({ type:'window', includeUncontrolled:true }).then(list => {
      const existing = list.find(c => c.url.includes('index.html') || c.url.endsWith('/'));
      if (existing) return existing.focus();
      return clients.openWindow('./');
    })
  );
});
